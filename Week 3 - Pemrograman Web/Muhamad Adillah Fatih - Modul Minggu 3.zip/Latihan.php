<?php
$nama = "Muhamad Adillah Fatih";
$nim = 121103017;

$nilai1 = 10;
$nilai2 = 7;

$bobotNilai1 = 2;
$bobotNilai2 = 8;

$totalNilai = ($nilai1 * $bobotNilai1) + ($nilai2 * $bobotNilai2);
$hasilnilai= $nilai1 + $nilai2;

echo "Total Nilai: {$totalNilai} <br>";
echo "Hasil dari $nilai1 + {$nilai2} adalah: {$hasilnilai} <br> <br>";

echo "Nama: {$nama} <br>";
echo "NIM: {$nim}";
?>