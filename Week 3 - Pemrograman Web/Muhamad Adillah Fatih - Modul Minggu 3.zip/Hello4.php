<?php
echo "<html>
<body>
Hello World
Sedang belajar PHP
</body>
</html>"
?>