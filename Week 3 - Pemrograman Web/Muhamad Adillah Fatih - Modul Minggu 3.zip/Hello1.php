<?php
echo "Hallo Dunia!";
?>