<?php
$apakahSiswaLulus = true;
$apakahSiswaSudahUjian = false;

echo "Apakah Siswa Lulus: ";
var_dump($apakahSiswaLulus);
echo "<br>";
echo "Apakah Siswa Sudah Ujian: ";
var_dump($apakahSiswaSudahUjian);
?>