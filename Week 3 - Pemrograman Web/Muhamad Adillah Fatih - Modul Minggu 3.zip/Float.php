<?php
$nilaiMatematika = 5.1;
$nilaiIpa = 6.7;
$nilaiBahasaIndonesia = 9.3;

$rataRata = ($nilaiMatematika + $nilaiIpa + $nilaiBahasaIndonesia) / 3;

echo "Nilai Maematika: {$nilaiMatematika} <br>";
echo "Nilai Ipa: {$nilaiIpa} <br>";
echo "Nilai Bahasa Indonesia: {$nilaiBahasaIndonesia} <br>";
echo "Rata-Rata: {$rataRata} <br>";

var_dump($rataRata);
?>